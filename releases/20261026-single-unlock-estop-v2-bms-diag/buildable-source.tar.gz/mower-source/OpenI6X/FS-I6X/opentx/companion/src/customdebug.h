/*
 * Copyright (C) OpenTX
 *
 * Based on code named
 *   th9x - http://code.google.com/p/th9x
 *   er9x - http://code.google.com/p/er9x
 *   gruvin9x - http://code.google.com/p/gruvin9x
 *
 * License GPLv2: http://www.gnu.org/licenses/gpl-2.0.html
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#ifndef _CUSTOMDEBUG_H_
#define _CUSTOMDEBUG_H_

#include <QLoggingCategory>

// Controls the generation of debug output for EEPROM import
Q_DECLARE_LOGGING_CATEGORY(eepromImport)  // "eeprom.import"

// Controls the generation of debug output of SimulatorLoader class
Q_DECLARE_LOGGING_CATEGORY(simulatorInterfaceLoader)  // "simulator.interface.loader"

class CustomDebug
{
  public:
    static void setFilterRules();
};

#endif // _CUSTOMDEBUG_H_
